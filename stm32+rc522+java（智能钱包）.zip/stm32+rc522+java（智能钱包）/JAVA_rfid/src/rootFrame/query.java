package rootFrame;

import java.nio.ByteBuffer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import DB.DB;

public class query {
	//��ѯ
	static public void chaxun(){
		//����ѧ�ŵ�ȡ���ݿ�����Ӧ����Ϣ
        String No = MainFrame.txtNo.getText().toString();
        String sql = "select * from user where userNo ="+"'"+No+"'";
		System.out.print(sql);
		//dbsave()�������ݿ�����
		try {
		//��ȡ���ݿ��е�������Ϣ
		Connection conn = DB.getConnection();
		PreparedStatement pstmt=conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery(sql);
		 ByteBuffer bb = ByteBuffer.allocate(1024 * 1024);  
		 while(rs.next()) {
			 //gettxt();
			String yname = rs.getString("username");
			String yclass = rs.getString("userclass");
			String ymoney = rs.getString("usermoney");
//	        byte[] buffer = new byte[1];  
//	        InputStream image = rs.getBinaryStream(7);  
//	               try {
//			//			//showimage 
//			ImageIcon icon = new ImageIcon(bb.array());  
//			icon.setImage(icon.getImage().getScaledInstance(100,100,Image.BOTTOM));
//			Image.setIcon(icon); 		while (image != null && image.read(buffer) > 0) {  
//					       bb.put(buffer);  
//					   }
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}                
//			//showimage 
//			ImageIcon icon = new ImageIcon(bb.array());  
//			icon.setImage(icon.getImage().getScaledInstance(100,100,Image.BOTTOM));
//			Image.setIcon(icon); 
			MainFrame.txtname.setText(yname);
			MainFrame.textclass.setText(yclass);
			MainFrame.txtmoney.setText(ymoney);
		 	//Image.setText(yImage);
		 	
		} 
		}
		catch(Exception e){
			e.printStackTrace();
		}

	}

}
