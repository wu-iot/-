package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
/**
 * ���ݿ�ӿ���
 *
 */
	public class DB {

	    public static Connection getConnection()
		{
			Connection conn=null; 
			try {
				Class.forName("org.gjt.mm.mysql.Driver");
				//JOptionPane.showMessageDialog(null,"���������ɹ���");
				 conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/rfid?useUnicode=true&characterEncoding=UTF-8","guanli","123456");
				 //JOptionPane.showMessageDialog(null,"���ݿ����ӳɹ�");
				}catch(Exception e)
				{
					JOptionPane.showMessageDialog(null,"���ݿ�����ʧ��");
					e.printStackTrace();
				}
			return conn;
		}
	    public void closeAll() {
	    	Connection conn=null; 
	    	PreparedStatement pstmt = null;
	    	ResultSet rs =null;
	    	if(rs != null)
	    	{
	    		try {rs.close();}
	    		catch(Exception e){e.printStackTrace();}
	    	}
	    	
	    	if(pstmt !=null) {
	    		try {pstmt.close();}
	    		catch(Exception e){e.printStackTrace();}
	    	}
	    	if(conn !=null) {
	    		try {conn.close();}
	    		catch(Exception e){e.printStackTrace();}
	    	}
	    }
	    
}