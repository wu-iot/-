package rootFrame;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DB.DB;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class updaterootFrame extends JFrame {

	private JPanel contentPane;
	private JTextField txtname;
	private JLabel Lbphone;
	private JTextField txtphone;
	private JLabel Lbusername;
	private JTextField txtusername;
	private JLabel Lbuserpaw1;
	private JTextField txtuserpaw1;
	private JLabel Lbusernewpaw1;
	private JTextField txtusernewpaw1;
	private JButton btsure;
	private JButton btcannel;
	private JLabel Lbusernewpaw2;
	private JTextField txtusernewpaw2;
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					updaterootFrame frame = new updaterootFrame();
					frame.setTitle("���ӹ�����Ա");

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public updaterootFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 231, 252);
		setTitle("�޸�����");
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel Lbname = new JLabel("\u59D3\u540D\uFF1A");
		Lbname.setBounds(10, 28, 54, 15);
		contentPane.add(Lbname);
		
		txtname = new JTextField();
		txtname.setBounds(68, 25, 135, 21);
		contentPane.add(txtname);
		txtname.setColumns(10);
		
		Lbphone = new JLabel("\u8054\u7CFB\u7535\u8BDD\uFF1A");
		Lbphone.setBounds(10, 53, 64, 15);
		contentPane.add(Lbphone);
		
		txtphone = new JTextField();
		txtphone.setBounds(78, 50, 125, 21);
		contentPane.add(txtphone);
		txtphone.setColumns(10);
		
		Lbusername = new JLabel("\u7528\u6237\u540D\uFF1A");
		Lbusername.setBounds(10, 78, 64, 15);
		contentPane.add(Lbusername);
		
		txtusername = new JTextField();
		txtusername.setBounds(79, 78, 124, 21);
		contentPane.add(txtusername);
		txtusername.setColumns(10);
		
		Lbuserpaw1 = new JLabel("\u539F\u5BC6\u7801\uFF1A");
		Lbuserpaw1.setBounds(10, 103, 53, 15);
		contentPane.add(Lbuserpaw1);
		
		txtuserpaw1 = new JTextField();
		txtuserpaw1.setBounds(68, 103, 136, 21);
		contentPane.add(txtuserpaw1);
		txtuserpaw1.setColumns(10);
		
		Lbusernewpaw1 = new JLabel("\u65B0\u5BC6\u7801\uFF1A");
		Lbusernewpaw1.setBounds(10, 129, 54, 15);
		contentPane.add(Lbusernewpaw1);
		
		txtusernewpaw1 = new JTextField();
		txtusernewpaw1.setBounds(68, 126, 135, 21);
		contentPane.add(txtusernewpaw1);
		txtusernewpaw1.setColumns(10);
		
		Lbusernewpaw2 = new JLabel("\u786E\u8BA4\u5BC6\u7801\uFF1A");
		Lbusernewpaw2.setBounds(10, 154, 64, 15);
		contentPane.add(Lbusernewpaw2);
		
		txtusernewpaw2 = new JTextField();
		txtusernewpaw2.setBounds(88, 151, 115, 21);
		contentPane.add(txtusernewpaw2);
		txtusernewpaw2.setColumns(10);
		
		btsure = new JButton("\u786E\u5B9A");
		btsure.setBounds(10, 182, 93, 23);
		contentPane.add(btsure);
		
		btcannel = new JButton("\u53D6\u6D88");
		btcannel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updaterootFrame.this.setVisible(false);
				new MainFrame();
			}
		});
		btcannel.setBounds(110, 182, 93, 23);
		contentPane.add(btcannel);
		xianshi();
		this.setVisible(true);
		this.setDefaultCloseOperation(3);//���ô�����Խ��йر�
		this.setLocationRelativeTo(null);//���ô�������Ļ���м�
		this.setResizable(false);//��ֹ��������
	}
	public void xianshi() {
		
		String sql1="select name,phone,username from addroot";
			try {
				//��ȡ���ݿ��е�������Ϣ
				 conn = DB.getConnection();
				 pstmt=conn.prepareStatement(sql1);
				 rs = pstmt.executeQuery(sql1);
				 while(rs.next()) {
					 String name=rs.getString("name");
					 System.out.println(name);
		}
	}catch(SQLException e) {
		e.printStackTrace();
	}
}}
