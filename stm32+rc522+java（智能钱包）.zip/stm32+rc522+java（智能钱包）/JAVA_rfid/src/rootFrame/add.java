package rootFrame;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

import DB.DB;
import rootFrame.readcard;

public class add {
	//private static final String Image = null;
	public static String fileString;
	static void shangchuan() 
	{
		int width = 185;
        int height = 255;
		JFileChooser jc = new JFileChooser();
		jc.setFileFilter(new FileFilter() {
			public boolean accept(File f) { // �趨���õ��ļ��ĺ�׺��
				if (f.getName().endsWith(".jpg") || f.isDirectory()
						|| f.getName().endsWith(".gif")
						|| f.getName().endsWith(".bmp")) {
					return true;
				}
				return false;
			}

			public String getDescription() {
				return "ͼƬ(*.jpg,*.gif,*bmp)";
			}

			
		});
		int returnValue = jc.showOpenDialog(null);
		
		if (returnValue == JFileChooser.APPROVE_OPTION) {
			File selectedFile = jc.getSelectedFile();
			if (selectedFile != null) {
				fileString = selectedFile.getAbsolutePath();
				try {
					BufferedImage newImage = ImageIO.read(new File(fileString));

					ImageIcon image=new ImageIcon(newImage);
					image.setImage(image.getImage().getScaledInstance(width,height,MainFrame.Image.ABORT));
					
					MainFrame.Image.setIcon(image);

				} catch (IOException ex) {
					System.out.println(ex);
				}

			}
		}
	}
	static void readcard() {
		readcard read= new readcard();
    	read.openComPort(); //�򿪶˿� 
    	read.mesg = "1231"; //��÷����ı������� 
        read.sendDataToSeriaPort(); //������Ϣ���˿� 	
    	JOptionPane.showMessageDialog(null, "�����ɹ���");
    	MainFrame.textcardNo.setText(read.str);
        //System.out.println(read.str);
        read.closeSerialPort();//�رմ���
	}
	static void chushihua() {
		readcard read1= new readcard();
    	read1.openComPort(); //�򿪶˿� 
    	read1.mesg = "1232"; //��÷����ı������� 
        read1.sendDataToSeriaPort(); //������Ϣ���˿� 	
    	JOptionPane.showMessageDialog(null, "��ʼ���ɹ���");
    	MainFrame.textmoney.setText(read1.str);
        System.out.println(read1.str);
        read1.closeSerialPort();//�رմ���
	}
	static void clean() 
	{
		MainFrame.textname.setText("");
		MainFrame.txtphone.setText("");
		MainFrame.textNo.setText("");
		MainFrame.textmoney.setText("");
		MainFrame.txtclass.setText("");
		MainFrame.textcardNo.setText("");
		MainFrame.Image.setText("");
	}
	static void writerdb() {
		
		//��ȡ��ǰϵͳʱ��
		SimpleDateFormat tempDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
		String userdate = tempDate.format(new java.util.Date()); 
		//gettxt()
		String usercardNo = MainFrame.textcardNo.getText().trim().toString();
		String userNo = MainFrame.textNo.getText().trim().toString();
		String username = MainFrame.textname.getText().trim().toString();
		String userclass = MainFrame.txtclass.getText().toString();
		String userphone = MainFrame.txtphone.getText().trim().toString();
		String usermoney = MainFrame.textmoney.getText().trim().toString();
		//getimage
				File image = new File(fileString); 
				FileInputStream fis = null;
				try {
					fis = new FileInputStream(image);
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
		//dbsave
		Connection conn = DB.getConnection();
		try {
			String sql ="insert into user values (?,?,?,?,?,?,?,?)";
			//��ȡ���ݿ��е�������Ϣ
			 PreparedStatement stmt=conn.prepareStatement(sql);
			 stmt.setString(1, usercardNo);
			 stmt.setString(2, userNo);
			 stmt.setString(3, username);
			 stmt.setString(4, userclass);
			 stmt.setString(5, userphone);
			 stmt.setString(6, usermoney);
			 stmt.setBinaryStream(7, fis, (int) image.length()); 
			 stmt.setString(8, userdate);
			 stmt.executeUpdate();
			 JOptionPane.showMessageDialog(null, "������Ϣ�ɹ���");
			}
		catch(SQLException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "������Ϣʧ�ܣ�");
		}
	}
}
