package rootFrame;

import DB.DB;
import rootFrame.readcard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class jiajian {
	static public void chaxun(){
		//����ѧ�ŵ�ȡ���ݿ�����Ӧ����Ϣ
        String No = MainFrame.textstuid3.getText().toString();
        String sql = "select usermoney from user where userNo ="+"'"+No+"'";
		System.out.print(sql);
		//dbsave()�������ݿ�����
		try {
		//��ȡ���ݿ��е�������Ϣ
		Connection conn = DB.getConnection();
		PreparedStatement pstmt2=conn.prepareStatement(sql);
		ResultSet rs = pstmt2.executeQuery(sql);
		 //ByteBuffer bb = ByteBuffer.allocate(1024 * 1024);  
		 while(rs.next()) {
			 //gettxt();
			//String yname = rs.getString("username");
			//String yclass = rs.getString("userclass");
			String ymoney = rs.getString("usermoney");
			System.out.println(ymoney);
//	        byte[] buffer = new byte[1];  
//	        InputStream image = rs.getBinaryStream(7);  
//	               try {
//					while (image != null && image.read(buffer) > 0) {  
//					       bb.put(buffer);  
//					   }
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}                
//			//showimage 
//			ImageIcon icon = new ImageIcon(bb.array());  
//			icon.setImage(icon.getImage().getScaledInstance(100,100,Image.BOTTOM));
//			Image.setIcon(icon); 
			MainFrame.textstumoney3.setText(ymoney);
		 	//Image.setText(yImage);
		 	
		} 
		}
		catch(Exception e){
			e.printStackTrace();
		}	
		}
	static public void chongzhi(){
		//��ֵ���
		readcard read1= new readcard();
    	read1.openComPort(); //�򿪶˿� 
    	String txtmoney=MainFrame.txtjia.getText().toString();
    	//System.out.println(money);
    	read1.mesg = txtmoney+"3"; //��÷����ı������� 
    	//System.out.println(read1.mesg);
        read1.sendDataToSeriaPort(); //������Ϣ���˿� 	
    	JOptionPane.showMessageDialog(null, "��ֵ�ɹ���");
    	String ymoney="";
    	String endmoney="";
    	int i,j,end;
        //txtmoney.setText(read1.str);
        //System.out.println(read1.str);
    	//gettxt
    	String No = MainFrame.textstuid3.getText().toString();
    	String sql2="update user set usermoney=?where userNo =?";
    	String sql1="select usermoney from user where userNo="+"'"+No+"'";
    	System.out.println(sql1);
    	Connection conn = DB.getConnection();
		//��ȡ���ݿ�ԭ����С
		try {
    		//��ȡ���ݿ��е�������Ϣ
			PreparedStatement pstmt1=conn.prepareStatement(sql1);
			ResultSet rs=pstmt1.executeQuery(sql1);
    		 while(rs.next()) {
    			 ymoney = rs.getString("usermoney");
    			 i=Integer.parseInt(ymoney);
    			 //System.out.println(i);
		//���ݿ����ֵ
    		//��ȡ���ݿ��е�������Ϣ
    		 j=Integer.parseInt(txtmoney);
    		 end=i+j;
    		 System.out.println(end);
    		endmoney=String.valueOf(end);
    		System.out.println(endmoney);
    		PreparedStatement pstmt2=conn.prepareStatement(sql2);
    		 pstmt2.setString(1, endmoney);
    		 pstmt2.setString(2, No);
    		 pstmt2.executeUpdate();
			 //JOptionPane.showMessageDialog(null, "��ֵ�ɹ�");
    		} }
    		catch(Exception e){
    			e.printStackTrace();
    		}	
        read1.closeSerialPort();//�رմ���
	}
	static public void jianzhi(){
		//��ֵ���
		readcard read1= new readcard();
    	read1.openComPort(); //�򿪶˿� 
    	String txtmoney=MainFrame.txtjian.getText().toString();
    	//System.out.println(money);
    	read1.mesg = txtmoney+"4"; //��÷����ı������� 
    	//System.out.println(read1.mesg);
        read1.sendDataToSeriaPort(); //������Ϣ���˿� 	
    	JOptionPane.showMessageDialog(null, "�۷ѳɹ���");
    	String ymoney="";
    	String endmoney="";
    	int i,j,end;
        //txtmoney.setText(read1.str);
        //System.out.println(read1.str);
    	//gettxt
    	String No = MainFrame.textstuid3.getText().toString();
    	String sql2="update user set usermoney=?where userNo =?";
    	String sql1="select usermoney from user where userNo="+"'"+No+"'";
    	System.out.println(sql1);
    	Connection conn = DB.getConnection();
		//��ȡ���ݿ�ԭ����С
		try {
    		//��ȡ���ݿ��е�������Ϣ
			PreparedStatement pstmt1=conn.prepareStatement(sql1);
			ResultSet rs=pstmt1.executeQuery(sql1);
    		 while(rs.next()) {
    			 ymoney = rs.getString("usermoney");
    			 i=Integer.parseInt(ymoney);
    			 //System.out.println(i);
		//���ݿ����ֵ
    		//��ȡ���ݿ��е�������Ϣ
    		 j=Integer.parseInt(txtmoney);
    		 end=i-j;
    		 System.out.println(end);
    		 if(end>=0) {
    		endmoney=String.valueOf(end);
    		System.out.println(endmoney);
    		PreparedStatement pstmt2=conn.prepareStatement(sql2);
    		 pstmt2.setString(1, endmoney);
    		 pstmt2.setString(2, No);
    		 pstmt2.executeUpdate();
			 //JOptionPane.showMessageDialog(null, "��ֵ�ɹ�");
    		} }}
    		catch(Exception e){
    			e.printStackTrace();
    		}	
        read1.closeSerialPort();//�رմ���
	}
}
