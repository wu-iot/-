package rootFrame;

import java.nio.ByteBuffer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import DB.DB;

public class addroot {
	//���浽���ݿ�
	static public void writeraddroot() {
		//gettxt()
		String name = MainFrame.txtusername.getText().trim().toString();
		String phone = MainFrame.txtuserphone.getText().trim().toString();
		String username = MainFrame.txtuser.getText().trim().toString();
		String userpaw1 = MainFrame.txtuserpaw1.getText().trim().toString();
		String userpaw2 = MainFrame.txtuserpaw2.getText().trim().toString();
	//�������ݿ�
		Connection conn = DB.getConnection();
		try {
			String paw = "";
			String sql1 = "select userpaw1 from addroot where username ="+"'"+username+"'";
			//System.out.print(sql1);
			//dbsave()�������ݿ�����
			//��ȡ���ݿ��е�������Ϣ
			Connection con = DB.getConnection();
			PreparedStatement pstmt=con.prepareStatement(sql1);
			ResultSet rs = pstmt.executeQuery(sql1);
			 while(rs.next()) {
				paw = rs.getString("userpaw1");
				//System.out.println(paw);
			}
			 if(paw.equals("")){
			if(userpaw1.equals(userpaw2)) {
				System.out.print("123");
				 String sql = "insert into addroot values(?,?,?,?,?)";
				 PreparedStatement stmt=con.prepareStatement(sql);
				 stmt.setString(1, name);
				 stmt.setString(2, phone);
				 stmt.setString(3, username);
				 stmt.setString(4, userpaw1);
				 stmt.setString(5, userpaw2);
				 stmt.executeUpdate();
				 JOptionPane.showMessageDialog(null, "���ӹ�����Ա�ɹ�");
			 }
			else {
				 JOptionPane.showMessageDialog(null, "�������벻һ�£�����������");
			}
			}else
			 {
				 JOptionPane.showMessageDialog(null, "�û��Ѵ���");
			 }
		}
		catch(SQLException e) {
				 e.printStackTrace();
				 JOptionPane.showMessageDialog(null, "���ӹ�����Աʧ��");
			 }
	}
	static public void updateroot(){
		//����ѧ�ŵ�ȡ���ݿ�����Ӧ����Ϣ
        String No = MainFrame.txtuser1.getText().toString();
        String userpaw = MainFrame.txtpaw.getText().toString();
        String paw1 = MainFrame.txtuserpaw1_1.getText().toString();
        String paw2 = MainFrame.txtuserpaw1_2.getText().toString();
        String sql = "select * from addroot where username ="+"'"+No+"'";
        String paw = "";
		//System.out.print(sql);
		//dbsave()�������ݿ�����
		try {
		//��ȡ���ݿ��е�������Ϣ
		Connection conn = DB.getConnection();
		PreparedStatement pstmt=conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery(sql);
		 while(rs.next()) {
			 //gettxt();
			paw = rs.getString("userpaw1");
		} 
		 if(paw.equals(""))
		 {
			 JOptionPane.showMessageDialog(null, "�û�������");
		 }
		 else if(paw.equals(userpaw)) 
		 {
			 if(paw1.equals(paw2)) {
				 String sql1="update addroot set userpaw1=?,userpaw2=? where username=?";
				 PreparedStatement pstmt1=conn.prepareStatement(sql1);
				 pstmt1.setString(1, paw1);
				 pstmt1.setString(2, paw2);
				 pstmt1.setString(3, No);
				 pstmt1.executeUpdate();
				 JOptionPane.showMessageDialog(null, "�޸�����ɹ�");
			 }
		 }
		}
		catch(Exception e){
			e.printStackTrace();
		}

	}
}
