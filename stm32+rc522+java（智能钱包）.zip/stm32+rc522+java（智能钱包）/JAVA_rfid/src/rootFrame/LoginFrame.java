package rootFrame;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DB.DB;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JTextField;
import java.awt.Dimension;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import java.awt.SystemColor;

public class LoginFrame extends JFrame {

	private JPanel login;
	private JTextField txtusername;
	private JPasswordField txtuserpaw;
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	private URL url =null;//����ͼƬ��URL
	private Image image = null;//����ͼ�����
	static int count=0;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrame frame = new LoginFrame();
					frame.setVisible(true);
					frame.setTitle("У԰���۷�ϵͳ");
					frame.setSize(450,250);//���ô����С
					frame.setDefaultCloseOperation(3);//���ô�����Խ��йر�
					frame.setLocationRelativeTo(null);//���ô�������Ļ���м�
					frame.setResizable(false);//��ֹ��������
					frame.setFont(new Font("����",Font.PLAIN,15));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 428, 212);
		login = new JPanel();
		login.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(login);
		login.setLayout(null);
		
		JLabel Title = new JLabel("\u6821\u56ED\u5361\u6263\u8D39\u7CFB\u7EDF");
		Title.setBounds(109, 10, 230, 42);
		Title.setFont(new Font("Dialog", Font.PLAIN, 30));
		login.add(Title);
		
		Panel p1 = new Panel();
		p1.setBounds(13, 58, 405, 40);
		login.add(p1);
		
		JLabel username = new JLabel("\u7BA1\u7406\u4EBA\u8D26\u53F7\uFF1A");
		p1.add(username);
		username.setFont(new Font("����", Font.PLAIN, 15));
		
		txtusername = new JTextField();
		p1.add(txtusername);
		txtusername.setPreferredSize(new Dimension(300, 30));
		
		JPanel p2 = new JPanel();
		p2.setBounds(13, 102, 405, 40);
		login.add(p2);
		
		JLabel userpaw = new JLabel("\u7BA1\u7406\u4EBA\u5BC6\u7801\uFF1A");
		userpaw.setFont(new Font("����", Font.PLAIN, 15));
		p2.add(userpaw);
		
		txtuserpaw = new JPasswordField();
		txtuserpaw.setPreferredSize(new Dimension(300, 30));
		p2.add(txtuserpaw);
		
		//��½��ť
		JButton btlogin = new JButton("");
		btlogin.setIcon(new ImageIcon(LoginFrame.class.getResource("/image/dl01.jpg")));
		btlogin.setBounds(223, 152, 53, 23);
		btlogin.setRolloverIcon(new ImageIcon(getClass().getResource(
				"/image/dl.jpg")));
		btlogin.setIcon(new ImageIcon(getClass().getResource(
				"/image/dl01.jpg")));
		login.add(btlogin);
		btlogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				checkdb();
			}
		});
		btlogin.setFont(new Font("����", Font.BOLD, 15));
		
		//���ð�ť
		JButton btreset = new JButton("");
		btreset.setIcon(new ImageIcon("D:\\exlipse\\rfid\\bin\\image\\cz01.jpg"));
		btreset.setBounds(286, 152, 53, 23);
		btreset.setRolloverIcon(new ImageIcon(getClass().getResource(
				"/image/cz.jpg")));
		btreset.setIcon(new ImageIcon(getClass().getResource(
				"/image/cz01.jpg")));
		login.add(btreset);
		btreset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtusername.setText("");
				txtuserpaw.setText("");
			}
		});
		btreset.setFont(new Font("����", Font.BOLD, 15));
		
		//�˳���ť
		JButton btexit = new JButton("");
		login.add(btexit);
		btexit.setFont(new Font("����", Font.BOLD, 15));
		btexit.setBackground(SystemColor.control);
		btexit.setIcon(new ImageIcon(LoginFrame.class.getResource("/image/tc01.jpg")));
		btexit.setRolloverIcon(new ImageIcon(getClass().getResource(
				"/image/tc.jpg")));
		btexit.setIcon(new ImageIcon(getClass().getResource(
				"/image/tc01.jpg")));
		btexit.setBounds(new Rectangle(349, 152, 53, 23));
		btexit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		//�Զ��屳��
        ImageIcon bgImg = new ImageIcon("image/background.jpg");
        JLabel bg = new JLabel(bgImg);
        Container laycon = this.getLayeredPane();
        bg.setSize(this.getSize().width, this.getSize().height);
        bgImg.setImage(bgImg.getImage().getScaledInstance(bg.getSize().width,
                bg.getSize().height, Image.SCALE_DEFAULT));
        laycon.add(bg, new Integer(Integer.MIN_VALUE));

	}
	private void checkdb() {
		boolean result =false;
		//DB db =new DB();
		//gettxt()
		String paw = "";
		String username1 = txtusername.getText().trim().toString();
		String userpaw = txtuserpaw.getText().trim().toString();
		//String userpaw  = txtuserpaw.getPassword().toString();
		String sql = "select userpaw1 from addroot where username ="+"'"+username1+"'";
		//System.out.print(sql);
		//dbsave()�������ݿ�����
		try {
		//��ȡ���ݿ��е�������Ϣ
		 conn = DB.getConnection();
		 pstmt=conn.prepareStatement(sql);
		 rs = pstmt.executeQuery(sql);
		 while(rs.next()) {
			paw = rs.getString("userpaw1");
		}
		 if(paw.equals(""))
		 {
			 JOptionPane.showMessageDialog(null, "�û�������");
		 }
		 
		 else if(paw.equals(userpaw)) 
		 {
			 LoginFrame.this.setVisible(false);
			 new MainFrame();
		 }
		 else
		 {
			 JOptionPane.showMessageDialog(null, "�������");
			 count++;
			 //System.out.print(count);
			 if(count==3) {
				 JOptionPane.showMessageDialog(null, "�����µ���̨��������");
				 System.exit(0);
			 }
		 }
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
