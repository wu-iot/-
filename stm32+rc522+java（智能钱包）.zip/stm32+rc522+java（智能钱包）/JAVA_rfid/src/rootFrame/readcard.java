package rootFrame;

import gnu.io.CommPortIdentifier;
import gnu.io.NoSuchPortException;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import gnu.io.UnsupportedCommOperationException;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.TooManyListenersException;
import javax.imageio.ImageIO;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class readcard extends JFrame implements ActionListener, SerialPortEventListener {    	
    protected CommPortIdentifier portId;        
    protected Enumeration<?> ports;        
    protected List<String> portList;    
    protected SerialPort serialPort;    
    protected OutputStream outputStream = null;     
    protected InputStream inputStream = null;  
    protected String mesg;        
    protected int sendCount, reciveCount;        
    public String str,Money;
//    boolean enable;
//    private Button read;
//    private JTextField readcard;
    protected int tem = 0;  
    protected int WIN_WIDTH = 380;        
    protected int WIN_HEIGHT = 300; 
    
    
    /** 
     * �����ж˿ڷ������� 
     */  
    public void sendDataToSeriaPort() {   
        try {   
            sendCount++;  
            outputStream.write(mesg.getBytes());   
            outputStream.flush();   
            //System.out.println("987");
        } catch (IOException e) {   
            showErrMesgbox(e.getMessage());  
        }              
    }   
//    public void initComponents() {  
//    	  // ���ó���  
//        Font lbFont = new Font("΢���ź�", Font.TRUETYPE_FONT, 14); 
//        JPanel p1 = new JPanel(); 
//        p1.setBounds(0, 0, 0, 0);
//        read = new Button("����");
//        read.addActionListener(new ActionListener() {
//        	public void actionPerformed(ActionEvent e) {
//        		    	//System.out.println("456");
////        		    	openComPort(); //�򿪶˿� 
////        		        mesg = "1231#"; //��÷����ı������� 
////        		        tem=1;
////        		        System.out.print(mesg);
////        		        sendDataToSeriaPort(); //������Ϣ���˿� 
//        	}
//        });
////        readcard= new JTextField(15);
////        p1.add(read);
////        p1.add(readcard);
////        getContentPane().add(p1);
//        }
//    public readcard() {          
//        super("Java RS-232����ͨ�Ų��Գ���");  
//        setSize(WIN_WIDTH, WIN_HEIGHT);  
//        setLocationRelativeTo(null);  
//        setResizable(false);  
//        //initComponents();    //��ʼ����UI��� 
//        //openComPort();
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
//        setVisible(true);  }
//    /** 
// * �򿪴��ж˿� 
// */  
public void openComPort() {
	//System.out.println("123");
    ports = CommPortIdentifier.getPortIdentifiers();
    if (ports.hasMoreElements()) {
        portId = (CommPortIdentifier) ports.nextElement();
        if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL) {
            if (portId.getName().equals("COM5")) {
                try {
                    serialPort = (SerialPort) portId.open("COM_5", 2000);
                } catch (PortInUseException e) {
                    e.printStackTrace();
                } 
                // �򿪶˿ڵ�IO���ܵ�   
                try {
                    inputStream = serialPort.getInputStream();
                    outputStream = serialPort.getOutputStream();
                } catch (IOException e) {
                    e.printStackTrace();
                }             
                // ���˿����Ӽ�����  
                try {
                    serialPort.addEventListener(this);
                } catch (TooManyListenersException e) {
                    e.printStackTrace();
                }
                serialPort.notifyOnDataAvailable(true);

                try {
                    serialPort.setSerialPortParams(9600,
                            SerialPort.DATABITS_8, SerialPort.STOPBITS_1,
                            SerialPort.PARITY_NONE);
                } catch (UnsupportedCommOperationException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

  
/** 
 * �رմ��ж˿� 
 */  
public void closeSerialPort() {   
    try {   
        if(outputStream != null)  
            outputStream.close();  
        if(serialPort != null)  
            serialPort.close();   
        serialPort = null;   
        //JOptionPane.showMessageDialog(null, "�رճɹ�");
    } catch (Exception e) {   
        showErrMesgbox(e.getMessage());  
    }   
}     
  
/** 
 * ��ʾ����򾯸���Ϣ 
 * @param msg ��Ϣ 
 */  
public void showErrMesgbox(String msg) {  
    JOptionPane.showMessageDialog(this, msg);  
}  
/** 
 * �������Ϊ�¼����� 
 */  
public void actionPerformed(ActionEvent e) {  

}  

/** 
 * �˿��¼����� 
 */  
public void serialEvent(SerialPortEvent event) {  
    switch (event.getEventType()) {  
        case SerialPortEvent.BI:  
        case SerialPortEvent.OE:  
        case SerialPortEvent.FE:  
        case SerialPortEvent.PE:  
        case SerialPortEvent.CD:  
        case SerialPortEvent.CTS:  
        case SerialPortEvent.DSR:  
        case SerialPortEvent.RI:  
        case SerialPortEvent.OUTPUT_BUFFER_EMPTY:  
            break;  
        case SerialPortEvent.DATA_AVAILABLE:  
            byte[] readBuffer = new byte[50];  

        try {  
            while (inputStream.available() > 0) {
            	try 
            	{ 
            	Thread.currentThread().sleep(500);//���� 
            	} 
            	catch(Exception e){}
                inputStream.read(readBuffer);  
            }  
            StringBuilder receivedMsg = new StringBuilder("");  
            receivedMsg.append(new String(readBuffer).trim()); 
//            System.out.println("123");
//            System.out.println(receivedMsg.toString());
            	str = receivedMsg.toString();
//            System.out.println(idNo);
           
//            switch(tem) 
//            {
//            case 1:
//            {
//            	readcard.setText(receivedMsg.toString());
//            	idNo = receivedMsg.toString();
//            	System.out.println(idNo);
//            	tem=0;break;
//            }
//            }
            //closeSerialPort(); 
        } catch (IOException e) {  
            showErrMesgbox(e.getMessage());  
        }  
    }  
}  

public static void main(String[] args) {  
    new readcard();  
    
}
}