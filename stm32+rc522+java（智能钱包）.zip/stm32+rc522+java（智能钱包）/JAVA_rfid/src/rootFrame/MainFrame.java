package rootFrame;
 
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
 
public class MainFrame extends JFrame{
	
		//�ϲ�����
	JButton jb1, jb2, jb3;//��¼��ȡ����ע����
	JPanel jp1;//ע�⣺panel��壬pane�Ǵ���
	
		//�в�����
	JTabbedPane jtp;// ѡ�����
	JPanel jp2, jp3, jp4,jp5;
	//������Ϣ
	private JButton btupload;
	public static JTextField textcardNo;
	public static JTextField textNo;
	public static JTextField textname;
	public static JTextField txtclass;
	public static JTextField txtphone;
	public static JTextField textmoney;
	public static JLabel Image;
	//��ѯ��Ϣ
	public static JTextField txtNo;
	public static JTextField txtname;
	public static JTextField textclass;
	public static JTextField txtmoney;
	private JLabel Image1;
	private JLabel label;
	//��ֵ�۷�
	public static JTextField textstuid3;
	public static JTextField textstumoney3;
	public static JTextField txtjian;
	public static JTextField txtjia;
		
	//����Ա��Ϣ����
	public static JTextField txtusername;
	public static JTextField txtuserphone;
	public static JTextField txtuser;
	public static JPasswordField txtuserpaw1;
	public static JPasswordField txtuserpaw2;
	//�޸�
	public static JPasswordField txtuserpaw1_1;
	public static JPasswordField txtpaw;
	public static JTextField txtuser1;
	public static JPasswordField txtuserpaw1_2;
	
	
	
	
	public static void main(String[] args) {
		MainFrame testLogin = new MainFrame();
 
	}
		//���캯��
	public MainFrame(){
		jtp = new JTabbedPane();	//ѡ�����
		
		//�в�QQ JPanel1
		jp2 = new JPanel();
		
		//�в��ֻ�JPanel2
		jp3 = new JPanel();
		
		//��������ӵ�ѡ�����
		jtp.add("¼����Ϣ", jp2);				
		jp2.setLayout(null);	
		btupload = new JButton("\u4E0A\u4F20");
		btupload.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				add.shangchuan();
			}
		});
		btupload.setBounds(302, 38, 93, 23);
		jp2.add(btupload);
		
		JLabel Lbcarno = new JLabel("\u5361    \u53F7\uFF1A");
		Lbcarno.setFont(new Font("����", Font.PLAIN, 13));
		Lbcarno.setBounds(323, 86, 72, 15);
		jp2.add(Lbcarno);
		
		JLabel LbNo = new JLabel("\u5B66    \u53F7\uFF1A");
		LbNo.setFont(new Font("����", Font.PLAIN, 13));
		LbNo.setBounds(323, 139, 72, 15);
		jp2.add(LbNo);
		
		JLabel Lbname = new JLabel("\u59D3    \u540D\uFF1A");
		Lbname.setFont(new Font("����", Font.PLAIN, 13));
		Lbname.setBounds(323, 194, 72, 15);
		jp2.add(Lbname);
		
		JLabel Lbclass = new JLabel("\u73ED    \u7EA7\uFF1A");
		Lbclass.setFont(new Font("����", Font.PLAIN, 13));
		Lbclass.setBounds(323, 255, 72, 15);
		jp2.add(Lbclass);
		
		JLabel Lbphone = new JLabel("\u8054\u7CFB\u65B9\u5F0F\uFF1A");
		Lbphone.setFont(new Font("����", Font.PLAIN, 13));
		Lbphone.setBounds(323, 302, 72, 15);
		jp2.add(Lbphone);
		
		JLabel Lbmoney = new JLabel("\u91D1    \u989D\uFF1A");
		Lbmoney.setFont(new Font("����", Font.PLAIN, 13));
		Lbmoney.setBounds(323, 351, 72, 15);
		jp2.add(Lbmoney);
		
		textcardNo = new JTextField();
		textcardNo.setBounds(405, 83, 134, 21);
		jp2.add(textcardNo);
		textcardNo.setColumns(10);
		
		JButton btread = new JButton("\u8BFB\u53D6");
		btread.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				add.readcard();
			}
		});
		btread.setBounds(567, 82, 93, 23);
		jp2.add(btread);
		
		textNo = new JTextField();
		textNo.setBounds(405, 136, 134, 21);
		jp2.add(textNo);
		textNo.setColumns(10);
		
		textname = new JTextField();
		textname.setBounds(405, 191, 134, 21);
		jp2.add(textname);
		textname.setColumns(10);
		
		txtclass = new JTextField();
		txtclass.setBounds(405, 252, 134, 21);
		jp2.add(txtclass);
		txtclass.setColumns(10);
		
		txtphone = new JTextField();
		txtphone.setBounds(405, 299, 134, 21);
		jp2.add(txtphone);
		txtphone.setColumns(10);
		
		textmoney = new JTextField();
		textmoney.setBounds(405, 348, 66, 21);
		jp2.add(textmoney);
		textmoney.setColumns(10);
		
		JButton btinitlize = new JButton("\u521D\u59CB\u5316");
		btinitlize.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				add.chushihua();
			}
		});
		btinitlize.setBounds(533, 347, 93, 23);
		jp2.add(btinitlize);
		
		JButton btsure = new JButton("\u786E\u8BA4");
		btsure.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				add.writerdb();
			}
		});
		btsure.setBounds(328, 409, 93, 23);
		jp2.add(btsure);
		
		JButton btreset = new JButton("\u91CD\u7F6E");
		btreset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				add.clean();
			}
		});
		btreset.setBounds(479, 409, 93, 23);
		jp2.add(btreset);
		
		Image = new JLabel("");
		Image.setBounds(47, 105, 185, 255);
		jp2.add(Image);
		
		
		
		jtp.add("��ѯ��Ϣ", jp3);
		jp3.setLayout(null);
		
		JLabel labstudenid = new JLabel("\u5B66\u53F7\uFF1A");
		labstudenid.setBounds(283, 116, 44, 15);
		jp3.add(labstudenid);
		
		txtNo = new JTextField();
		txtNo.setText("");
		txtNo.setColumns(10);
		txtNo.setBounds(363, 116, 144, 21);
		jp3.add(txtNo);
		
		JButton buttonchaxun = new JButton("\u67E5\u8BE2");
		buttonchaxun.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				query.chaxun();
			}
		});
		buttonchaxun.setBounds(535, 115, 63, 23);
		jp3.add(buttonchaxun);
		
		JLabel labstudentname = new JLabel("\u59D3\u540D\uFF1A");
		labstudentname.setBounds(283, 194, 44, 15);
		jp3.add(labstudentname);
		
		txtname = new JTextField();
		txtname.setColumns(10);
		txtname.setBounds(363, 191, 143, 21);
		jp3.add(txtname);
		
		JLabel labclass = new JLabel("\u73ED\u7EA7\uFF1A");
		labclass.setBounds(283, 260, 44, 15);
		jp3.add(labclass);
		
		textclass = new JTextField();
		textclass.setColumns(10);
		textclass.setBounds(363, 257, 144, 21);
		jp3.add(textclass);
		
		JLabel labmoney = new JLabel("\u91D1\u989D\uFF1A");
		labmoney.setBounds(283, 329, 44, 15);
		jp3.add(labmoney);
		
		txtmoney = new JTextField();
		txtmoney.setColumns(10);
		txtmoney.setBounds(363, 326, 75, 21);
		jp3.add(txtmoney);
		
		Image1 = new JLabel("");
		Image1.setBounds(26, 115, 229, 255);
		//showimage 
		ImageIcon icon = new ImageIcon("C:\\Users\\wu\\Desktop/people.jpg");  
		icon.setImage(icon.getImage().getScaledInstance(229,255,Image.BOTTOM));
		Image1.setIcon(icon); 
		jp3.add(Image1);
		
		
		//���봰��
		getContentPane().add(jtp, BorderLayout.CENTER);	//ѡ�����λ���в�
		
		jp4 = new JPanel();
		
		jtp.add("��ֵ�۷�", jp4);
		jp4.setLayout(null);
		
		label = new JLabel("");
		label.setFont(new Font("����", Font.BOLD, 25));
		label.setBounds(251, 233, 62, 36);
		jp4.add(label);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(213, 54, -94, 29);
		jp4.add(separator);
		
		JLabel label_1 = new JLabel("\u5B66\u53F7\uFF1A");
		label_1.setFont(new Font("����", Font.PLAIN, 14));
		label_1.setBounds(76, 31, 62, 39);
		jp4.add(label_1);
		
		JLabel label_2 = new JLabel("\u91D1\u989D\uFF1A");
		label_2.setFont(new Font("����", Font.PLAIN, 14));
		label_2.setBounds(76, 311, 62, 36);
		jp4.add(label_2);
		
		textstuid3 = new JTextField();
		textstuid3.setBounds(129, 40, 84, 21);
		jp4.add(textstuid3);
		textstuid3.setColumns(10);
		
		textstumoney3 = new JTextField();
		textstumoney3.setBounds(441, 40, 55, 21);
		jp4.add(textstumoney3);
		textstumoney3.setColumns(10);
		
		JButton button_1 = new JButton("\u67E5\u8BE2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				jiajian.chaxun();
			}
		});
		button_1.setBounds(236, 39, 93, 23);
		jp4.add(button_1);
		
		JButton button_2 = new JButton("\u5145\u503C");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				jiajian.chongzhi();
			}
		});
		button_2.setBounds(184, 318, 132, 23);
		jp4.add(button_2);
		
		JLabel label_3 = new JLabel("");
		label_3.setFont(new Font("����", Font.BOLD, 25));
		label_3.setBounds(576, 233, 62, 36);
		jp4.add(label_3);
		
		JButton button_4 = new JButton("\u6263\u8D39");
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				jiajian.jianzhi();
			}
		});
		button_4.setBounds(513, 318, 125, 23);
		jp4.add(button_4);
		
		txtjian = new JTextField();
		txtjian.setColumns(10);
		txtjian.setBounds(441, 319, 62, 21);
		jp4.add(txtjian);
		
		JLabel label_5 = new JLabel("\u91D1\u989D\uFF1A");
		label_5.setFont(new Font("����", Font.PLAIN, 14));
		label_5.setBounds(398, 311, 62, 36);
		jp4.add(label_5);
		
		JLabel label_4 = new JLabel("\u4F59\u989D\uFF1A");
		label_4.setFont(new Font("����", Font.PLAIN, 14));
		label_4.setBounds(398, 31, 62, 39);
		jp4.add(label_4);
		
		txtjia = new JTextField();
		txtjia.setColumns(10);
		txtjia.setBounds(112, 319, 62, 21);
		jp4.add(txtjia);
		
		JLabel Lbchong = new JLabel("");
		Lbchong.setBounds(109, 124, 204, 156);
		ImageIcon icon1 = new ImageIcon("D:\\java\\JAVA_rfid\\src\\Image/chong.jpg");  
		icon1.setImage(icon1.getImage().getScaledInstance(204,156,Image.BOTTOM));
		Lbchong.setIcon(icon1); 
		jp4.add(Lbchong);
		
		JLabel Lbkoufei = new JLabel("");
		Lbkoufei.setBounds(434, 124, 204, 156);
		ImageIcon icon2 = new ImageIcon("D:\\java\\JAVA_rfid\\src\\Image/kou.jpg");  
		icon2.setImage(icon2.getImage().getScaledInstance(204,156,Image.BOTTOM));
		Lbkoufei.setIcon(icon2); 
		jp4.add(Lbkoufei);
		
		jp5 = new JPanel();
		
		jtp.add("ϵͳ����Ա", jp5);
		jp5.setLayout(null);
		
		JLabel label_6 = new JLabel("\u6DFB\u52A0\u7BA1\u7406\u5458");
		label_6.setFont(new Font("����", Font.BOLD, 16));
		label_6.setBounds(163, 53, 112, 29);
		jp5.add(label_6);
		
		JLabel label_7 = new JLabel("\u59D3    \u540D\uFF1A");
		label_7.setFont(new Font("����", Font.PLAIN, 13));
		label_7.setBounds(86, 110, 73, 29);
		jp5.add(label_7);
		
		JLabel label_8 = new JLabel("\u8054\u7CFB\u7535\u8BDD\uFF1A");
		label_8.setFont(new Font("����", Font.PLAIN, 13));
		label_8.setBounds(86, 149, 73, 29);
		jp5.add(label_8);
		
		JLabel label_9 = new JLabel("\u7528\u6237\u540D\uFF1A");
		label_9.setFont(new Font("����", Font.PLAIN, 13));
		label_9.setBounds(86, 188, 62, 29);
		jp5.add(label_9);
		
		JLabel label_10 = new JLabel("\u5BC6    \u7801\uFF1A");
		label_10.setFont(new Font("����", Font.PLAIN, 13));
		label_10.setBounds(86, 240, 73, 29);
		jp5.add(label_10);
		
		JLabel label_11 = new JLabel("\u786E\u8BA4\u5BC6\u7801\uFF1A");
		label_11.setFont(new Font("����", Font.PLAIN, 13));
		label_11.setBounds(86, 283, 73, 29);
		jp5.add(label_11);
		
		txtusername = new JTextField();
		txtusername.setBounds(169, 114, 117, 21);
		jp5.add(txtusername);
		txtusername.setColumns(10);
		
		txtuserphone = new JTextField();
		txtuserphone.setColumns(10);
		txtuserphone.setBounds(169, 153, 117, 21);
		jp5.add(txtuserphone);
		
		txtuser = new JTextField();
		txtuser.setColumns(10);
		txtuser.setBounds(169, 192, 117, 21);
		jp5.add(txtuser);
		
		txtuserpaw1 = new JPasswordField();
		txtuserpaw1.setColumns(10);
		txtuserpaw1.setBounds(169, 244, 117, 21);
		jp5.add(txtuserpaw1);
		
		txtuserpaw2 = new JPasswordField();
		txtuserpaw2.setColumns(10);
		txtuserpaw2.setBounds(169, 287, 117, 21);
		jp5.add(txtuserpaw2);
		
		JButton btnuseradd = new JButton("\u786E\u8BA4");
		btnuseradd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				addroot.writeraddroot();
			}
		});
		btnuseradd.setBounds(149, 361, 93, 23);
		jp5.add(btnuseradd);
		
		JLabel label_12 = new JLabel("\u4FEE\u6539\u5BC6\u7801");
		label_12.setFont(new Font("����", Font.BOLD, 16));
		label_12.setBounds(466, 61, 112, 29);
		jp5.add(label_12);
		
		JLabel label_13 = new JLabel("\u786E\u8BA4\u5BC6\u7801\uFF1A");
		label_13.setFont(new Font("����", Font.PLAIN, 13));
		label_13.setBounds(399, 262, 73, 29);
		jp5.add(label_13);
		
		txtuserpaw1_1 = new JPasswordField();
		txtuserpaw1_1.setColumns(10);
		txtuserpaw1_1.setBounds(482, 213, 117, 21);
		jp5.add(txtuserpaw1_1);
		
		txtpaw = new JPasswordField();
		txtpaw.setColumns(10);
		txtpaw.setBounds(482, 170, 117, 21);
		jp5.add(txtpaw);
		
		JLabel label_14 = new JLabel("\u5BC6    \u7801\uFF1A");
		label_14.setFont(new Font("����", Font.PLAIN, 13));
		label_14.setBounds(399, 209, 73, 29);
		jp5.add(label_14);
		
		JLabel label_15 = new JLabel("\u7528\u6237\u540D\uFF1A");
		label_15.setFont(new Font("����", Font.PLAIN, 13));
		label_15.setBounds(399, 110, 62, 29);
		jp5.add(label_15);
		
		txtuser1 = new JTextField();
		txtuser1.setColumns(10);
		txtuser1.setBounds(482, 118, 117, 21);
		jp5.add(txtuser1);
		
		txtuserpaw1_2 = new JPasswordField();
		txtuserpaw1_2.setColumns(10);
		txtuserpaw1_2.setBounds(482, 266, 117, 21);
		jp5.add(txtuserpaw1_2);
		
		JLabel label_16 = new JLabel("\u539F\u5BC6\u7801\uFF1A");
		label_16.setFont(new Font("����", Font.PLAIN, 13));
		label_16.setBounds(399, 166, 73, 29);
		jp5.add(label_16);
		
		JButton button = new JButton("\u786E\u8BA4");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addroot.updateroot();
			}
		});
		button.setBounds(472, 361, 93, 23);
		jp5.add(button);
		
		this.setSize(700, 500);
		this.setResizable(false);	//��ֹ�ı䴰���С
		this.setTitle("У԰����Ϣ����ϵͳ");
		this.setLocationRelativeTo(null);//���ô�������Ļ���м�
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}